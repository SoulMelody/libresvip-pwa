from enum import Enum

XML_NS = "http://www.w3.org/XML/1998/namespace"


class LangValue(Enum):
    VALUE = ""
