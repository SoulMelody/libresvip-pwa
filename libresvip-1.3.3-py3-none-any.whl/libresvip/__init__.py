import os

__version__ = "1.3.3"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
