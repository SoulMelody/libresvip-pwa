import os

__version__ = "1.5.0"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
