import bisect
import dataclasses
import itertools
import math
from collections.abc import Callable
from typing import NamedTuple

import portion

from libresvip.core.constants import TICKS_IN_BEAT
from libresvip.core.time_sync import TimeSynchronizer

MAX_BREAK = 0.01
PORTAMENTO_HALFWIDTH_RATIO = 0.3
HALFWIDTH_FLOOR_SECS = 1.0 / 256
SIGMOID_EDGE_RESIDUAL_CENTS = 1.0
SMART_ANCHOR_SMOOTHNESS_OFFSET = 0.25
SMART_ANCHOR_SMOOTHNESS_LIMIT = 4.0
SMART_ANCHOR_BLEND_FALLOFF = 10.0


class NoteStruct(NamedTuple):
    key: int
    start: float
    end: float
    portamento_offset: float
    portamento_left: float
    portamento_right: float
    depth_left: float
    depth_right: float
    vibrato_start: float
    vibrato_left: float
    vibrato_right: float
    vibrato_depth: float
    vibrato_frequency: float
    vibrato_phase: float


class PitchControlPoint(NamedTuple):
    offset: int
    value: float


@dataclasses.dataclass
class PitchControl:
    pos: int
    pitch: float
    type_: str = "curve"
    points: list[PitchControlPoint] = dataclasses.field(default_factory=list)


@dataclasses.dataclass(frozen=True)
class PitchControlCurve:
    ticks: list[int]
    values: list[float]

    def value_at_ticks(self, ticks: int) -> float | None:
        index = bisect.bisect_right(self.ticks, ticks) - 1
        if index < 0:
            return None
        current_tick = self.ticks[index]
        current_value = self.values[index]
        if current_tick == ticks:
            return current_value
        next_index = index + 1
        if next_index >= len(self.ticks):
            return None
        next_tick = self.ticks[next_index]
        if ticks > next_tick:
            return None
        next_value = self.values[next_index]
        return current_value + (next_value - current_value) * (ticks - current_tick) / (
            next_tick - current_tick
        )

    def domain(self) -> portion.Interval:
        if not self.ticks:
            return portion.empty()
        return portion.closed(self.ticks[0], self.ticks[-1])


@dataclasses.dataclass
class PitchControlIntervalMap:
    curves: list[PitchControlCurve] = dataclasses.field(default_factory=list)
    _domain: portion.Interval = dataclasses.field(default_factory=portion.empty)
    _curve_starts: list[int] = dataclasses.field(default_factory=list)
    _curve_ends: list[int] = dataclasses.field(default_factory=list)
    _last_curve_index: int | None = None

    def append_curve(self, curve: PitchControlCurve) -> None:
        if not curve.ticks:
            return
        self.curves.append(curve)
        self._domain |= curve.domain()
        self._curve_starts.append(curve.ticks[0])
        self._curve_ends.append(curve.ticks[-1])
        self._last_curve_index = None

    def get(self, ticks: int) -> float | None:
        if (cached_index := self._last_curve_index) is not None:
            cached_curve = self.curves[cached_index]
            if (
                cached_curve.ticks[0] <= ticks <= cached_curve.ticks[-1]
                and (cached_value := cached_curve.value_at_ticks(ticks)) is not None
            ):
                return cached_value
        candidate_indexes = self._candidate_curve_indexes(ticks)
        for index in reversed(candidate_indexes):
            curve = self.curves[index]
            if (value := curve.value_at_ticks(ticks)) is not None:
                self._last_curve_index = index
                return value
        self._last_curve_index = None
        return None

    def _candidate_curve_indexes(self, ticks: int) -> range:
        right = bisect.bisect_right(self._curve_starts, ticks)
        left = bisect.bisect_left(self._curve_ends, ticks)
        if left >= right:
            return range(0)
        return range(left, right)

    def domain(self) -> portion.Interval:
        return self._domain


@dataclasses.dataclass
class SigmoidNode:
    start: float = dataclasses.field(init=False)
    end: float = dataclasses.field(init=False)
    center: float = dataclasses.field(init=False)
    key_left: int = dataclasses.field(init=False)
    key_right: int = dataclasses.field(init=False)
    sigmoid: Callable[[float], float] = dataclasses.field(init=False)
    d_sigmoid: Callable[[float], float] = dataclasses.field(init=False)
    _center: dataclasses.InitVar[float]
    _half_left: dataclasses.InitVar[float]
    _half_right: dataclasses.InitVar[float]
    _key_left: dataclasses.InitVar[int]
    _key_right: dataclasses.InitVar[int]

    def __post_init__(
        self,
        _center: float,
        _half_left: float,
        _half_right: float,
        _key_left: int,
        _key_right: int,
    ) -> None:
        self.center = _center
        self.key_left = _key_left
        self.key_right = _key_right
        h = (_key_right - _key_left) * 100
        base = _key_left * 100
        k = 3.0 / (_half_left + _half_right)
        margin = math.log(max(abs(h) / SIGMOID_EDGE_RESIDUAL_CENTS - 1.0, 1.0)) / k
        self.start = _center - margin
        self.end = _center + margin

        def _logistic(x: float) -> float:
            arg = k * (x - self.center)
            if arg >= 10.0:
                return base + h
            if arg <= -10.0:
                return base
            return base + h / (1.0 + math.exp(-arg))

        def _d_logistic(x: float) -> float:
            arg = k * (x - self.center)
            if arg >= 10.0 or arg <= -10.0:
                return 0.0
            e = math.exp(-arg)
            return h * k * e / (1.0 + e) ** 2

        self.sigmoid = _logistic
        self.d_sigmoid = _d_logistic

    def value_at_secs(self, secs: float) -> float:
        return self.sigmoid(secs)

    def slope_at_secs(self, secs: float) -> float:
        return self.d_sigmoid(secs)


@dataclasses.dataclass
class BaseLayerGenerator:
    _note_list: dataclasses.InitVar[list[NoteStruct]]
    note_list: list[NoteStruct] = dataclasses.field(init=False)
    sigmoid_nodes: list[SigmoidNode] = dataclasses.field(default_factory=list)
    _starts: list[float] = dataclasses.field(init=False, default_factory=list)
    _ends: list[float] = dataclasses.field(init=False, default_factory=list)
    _note_starts: list[float] = dataclasses.field(init=False, default_factory=list)
    _note_ends: list[float] = dataclasses.field(init=False, default_factory=list)
    _last_note_index: int | None = dataclasses.field(init=False, default=None)

    def __post_init__(self, _note_list: list[NoteStruct]) -> None:
        self.note_list = _note_list
        if not _note_list:
            return
        for current_note, next_note in itertools.pairwise(self.note_list):
            if current_note.key == next_note.key:
                continue
            if next_note.start - current_note.end > MAX_BREAK:
                continue
            half_left = max(
                next_note.portamento_left * PORTAMENTO_HALFWIDTH_RATIO,
                HALFWIDTH_FLOOR_SECS,
            )
            half_right = max(
                current_note.portamento_right * PORTAMENTO_HALFWIDTH_RATIO,
                HALFWIDTH_FLOOR_SECS,
            )
            mid = (current_note.end + next_note.start) / 2 + next_note.portamento_offset
            self.sigmoid_nodes.append(
                SigmoidNode(
                    _center=mid,
                    _half_left=half_left,
                    _half_right=half_right,
                    _key_left=current_note.key,
                    _key_right=next_note.key,
                )
            )
        self._starts = [node.start for node in self.sigmoid_nodes]
        self._ends = [node.end for node in self.sigmoid_nodes]
        self._note_starts = [note.start for note in self.note_list]
        self._note_ends = [note.end for note in self.note_list]

    def pitch_at_secs(self, secs: float) -> float:
        if not self.note_list:
            return 0.0
        left_index = bisect.bisect_right(self._ends, secs)
        right_index = bisect.bisect_right(self._starts, secs)
        query_count = right_index - left_index
        if query_count <= 0:
            note_index = self._find_note_index(secs)
            if note_index is not None:
                return self.note_list[note_index].key * 100
            return self.note_list[self._nearest_note_index(secs)].key * 100
        if query_count == 1:
            return self.sigmoid_nodes[left_index].value_at_secs(secs)
        first = self.sigmoid_nodes[left_index]
        last = self.sigmoid_nodes[right_index - 1]
        width = first.end - last.start
        bottom = first.value_at_secs(last.start)
        top = last.value_at_secs(first.end)
        diff1 = first.slope_at_secs(last.start)
        diff2 = last.slope_at_secs(first.end)
        x = secs - last.start
        a = (2 * (bottom - top) + (diff1 + diff2) * width) / width**3
        b = (3 * (top - bottom) - 2 * diff1 * width - diff2 * width) / width**2
        return a * x**3 + b * x**2 + diff1 * x + bottom

    def _find_note_index(self, secs: float) -> int | None:
        if (last_index := self._last_note_index) is not None:
            note = self.note_list[last_index]
            if note.start <= secs < note.end:
                return last_index
            next_index = last_index + 1
            if next_index < len(self.note_list):
                next_note = self.note_list[next_index]
                if next_note.start <= secs < next_note.end:
                    self._last_note_index = next_index
                    return next_index
            prev_index = last_index - 1
            if prev_index >= 0:
                prev_note = self.note_list[prev_index]
                if prev_note.start <= secs < prev_note.end:
                    self._last_note_index = prev_index
                    return prev_index
        index = bisect.bisect_right(self._note_starts, secs) - 1
        if index >= 0 and secs < self._note_ends[index]:
            self._last_note_index = index
            return index
        self._last_note_index = None
        return None

    def _nearest_note_index(self, secs: float) -> int:
        insert_index = bisect.bisect_left(self._note_starts, secs)
        candidates: list[int] = []
        if insert_index < len(self.note_list):
            candidates.append(insert_index)
        if insert_index > 0:
            candidates.append(insert_index - 1)
        if not candidates:
            return 0
        return min(
            candidates,
            key=lambda index: min(
                abs(self.note_list[index].start - secs),
                abs(secs - self.note_list[index].end),
            ),
        )


@dataclasses.dataclass
class GaussianNode:
    origin: float
    sigma: float
    depth: float
    start: float = dataclasses.field(init=False)
    end: float = dataclasses.field(init=False)

    def __post_init__(self) -> None:
        self.start = self.origin - 5.0 * self.sigma
        self.end = self.origin + 5.0 * self.sigma

    def value_at_secs(self, secs: float) -> float:
        return self.depth * math.exp(-0.5 * ((secs - self.origin) / self.sigma) ** 2)


def _portamento_sigma(portamento: float) -> float:
    return max(portamento * PORTAMENTO_HALFWIDTH_RATIO, HALFWIDTH_FLOOR_SECS)


@dataclasses.dataclass
class _ActiveRangeMixin:
    _starts: list[float] = dataclasses.field(init=False, default_factory=list)
    _ends: list[float] = dataclasses.field(init=False, default_factory=list)
    _last_range: tuple[int, int] | None = dataclasses.field(init=False, default=None)

    def _active_range(self, secs: float) -> tuple[int, int]:
        if (last_range := self._last_range) is not None:
            left_index, right_index = last_range
            if self._range_matches(secs, left_index, right_index):
                return last_range
        left_index = bisect.bisect_right(self._ends, secs)
        right_index = bisect.bisect_right(self._starts, secs)
        self._last_range = (left_index, right_index)
        return left_index, right_index

    def _range_matches(self, secs: float, left_index: int, right_index: int) -> bool:
        left_boundary = self._ends[left_index - 1] if left_index > 0 else float("-inf")
        if right_index > left_index:
            right_boundary = (
                self._ends[left_index] if left_index < len(self._ends) else float("inf")
            )
        else:
            right_boundary = (
                self._starts[right_index] if right_index < len(self._starts) else float("inf")
            )
        return left_boundary < secs < right_boundary


@dataclasses.dataclass
class GaussianLayerGenerator(_ActiveRangeMixin):
    _note_list: dataclasses.InitVar[list[NoteStruct]]
    gaussian_nodes: list[GaussianNode] = dataclasses.field(default_factory=list)

    def __post_init__(self, _note_list: list[NoteStruct]) -> None:
        if not _note_list:
            return
        first_note = _note_list[0]
        sigma_first = _portamento_sigma(first_note.portamento_left)
        self.gaussian_nodes.append(
            GaussianNode(
                origin=first_note.start + 1.5 * sigma_first,
                sigma=sigma_first,
                depth=-first_note.depth_left * 100,
            )
        )
        for current_note, next_note in itertools.pairwise(_note_list):
            sigma_l = _portamento_sigma(current_note.portamento_right)
            sigma_r = _portamento_sigma(next_note.portamento_left)
            if next_note.start - current_note.end > MAX_BREAK:
                self.gaussian_nodes.append(
                    GaussianNode(
                        origin=current_note.end - 1.5 * sigma_l,
                        sigma=sigma_l,
                        depth=-current_note.depth_right * 100,
                    )
                )
                self.gaussian_nodes.append(
                    GaussianNode(
                        origin=next_note.start + 1.5 * sigma_r,
                        sigma=sigma_r,
                        depth=-next_note.depth_left * 100,
                    )
                )
                continue
            center = (current_note.end + next_note.start) / 2 + next_note.portamento_offset
            depth_left = current_note.depth_right * 100
            depth_right = next_note.depth_left * 100
            if next_note.key <= current_note.key:
                depth_right = -depth_right
            else:
                depth_left = -depth_left
            self.gaussian_nodes.append(
                GaussianNode(
                    origin=center - 1.5 * sigma_l,
                    sigma=sigma_l,
                    depth=depth_left,
                )
            )
            self.gaussian_nodes.append(
                GaussianNode(
                    origin=center + 1.5 * sigma_r,
                    sigma=sigma_r,
                    depth=depth_right,
                )
            )
        last_note = _note_list[-1]
        sigma_last = _portamento_sigma(last_note.portamento_right)
        self.gaussian_nodes.append(
            GaussianNode(
                origin=last_note.end - 1.5 * sigma_last,
                sigma=sigma_last,
                depth=-last_note.depth_right * 100,
            )
        )
        self._starts = [node.start for node in self.gaussian_nodes]
        self._ends = [node.end for node in self.gaussian_nodes]

    def pitch_diff_at_secs(self, secs: float) -> float:
        left_index, right_index = self._active_range(secs)
        return sum(
            self.gaussian_nodes[index].value_at_secs(secs)
            for index in range(left_index, right_index)
        )


@dataclasses.dataclass
class VibratoNode:
    start: float
    end: float
    fade_left: float
    fade_right: float
    amplitude: float
    frequency: float
    phase: float

    def value_at_secs(self, secs: float) -> float:
        if self.end - self.start >= self.fade_left + self.fade_right:
            if self.fade_left > 0 and secs < self.start + self.fade_left:
                zoom = (secs - self.start) / self.fade_left
            elif self.fade_right > 0 and secs > self.end - self.fade_right:
                zoom = (self.end - secs) / self.fade_right
            else:
                zoom = 1.0
        else:
            fade_sum = self.fade_left + self.fade_right
            if fade_sum <= 0:
                mid = self.start
            else:
                mid = (self.start * self.fade_right + self.end * self.fade_left) / fade_sum
            if self.fade_left > 0 and secs < mid:
                zoom = (secs - self.start) / self.fade_left
            elif self.fade_right > 0:
                zoom = (self.end - secs) / self.fade_right
            else:
                zoom = 1.0
        return (
            self.amplitude
            * zoom
            * 100.0
            * math.sin(math.tau * self.frequency * (secs - self.start) + self.phase)
        )


@dataclasses.dataclass
class VibratoLayerGenerator(_ActiveRangeMixin):
    _note_list: dataclasses.InitVar[list[NoteStruct]]
    vibrato_nodes: list[VibratoNode] = dataclasses.field(default_factory=list)

    def __post_init__(self, _note_list: list[NoteStruct]) -> None:
        for i in range(len(_note_list)):
            start, end = _note_list[i].start, _note_list[i].end
            if end - start <= _note_list[i].vibrato_start:
                continue
            if i < len(_note_list) - 1 and _note_list[i + 1].start - end < MAX_BREAK:
                end += min(
                    max(0.0, _note_list[i + 1].portamento_offset),
                    min(
                        _note_list[i + 1].vibrato_start,
                        _note_list[i + 1].end - _note_list[i + 1].start,
                    ),
                )
            if start >= end:
                continue
            self.vibrato_nodes.append(
                VibratoNode(
                    start=start + _note_list[i].vibrato_start,
                    end=end,
                    fade_left=_note_list[i].vibrato_left,
                    fade_right=_note_list[i].vibrato_right,
                    amplitude=_note_list[i].vibrato_depth / 2,
                    frequency=_note_list[i].vibrato_frequency,
                    phase=_note_list[i].vibrato_phase,
                )
            )
        self._starts = [node.start for node in self.vibrato_nodes]
        self._ends = [node.end for node in self.vibrato_nodes]

    def pitch_diff_at_secs(self, secs: float) -> float:
        left_index, right_index = self._active_range(secs)
        return sum(
            self.vibrato_nodes[index].value_at_secs(secs)
            for index in range(left_index, right_index)
        )


def _hermite_interpolate(t: float, p0: float, p1: float, m0: float, m1: float) -> float:
    t2 = t * t
    t3 = t2 * t
    return (
        (2 * t3 - 3 * t2 + 1) * p0
        + (-2 * t3 + 3 * t2) * p1
        + (t3 - 2 * t2 + t) * m0
        + (t3 - t2) * m1
    )


def _smart_anchor_tangent(
    prev_anchor: tuple[int, float] | None,
    curr_anchor: tuple[int, float],
    next_anchor: tuple[int, float],
    next_next_anchor: tuple[int, float] | None,
    is_start_tangent: bool,
) -> float:
    time_span = next_anchor[0] - curr_anchor[0]
    if is_start_tangent:
        if prev_anchor is None:
            return next_anchor[1] - curr_anchor[1]
        slope_left = (curr_anchor[1] - prev_anchor[1]) / (curr_anchor[0] - prev_anchor[0])
        slope_right = (next_anchor[1] - curr_anchor[1]) / time_span
    else:
        if next_next_anchor is None:
            return next_anchor[1] - curr_anchor[1]
        slope_left = (next_anchor[1] - curr_anchor[1]) / time_span
        slope_right = (next_next_anchor[1] - next_anchor[1]) / (
            next_next_anchor[0] - next_anchor[0]
        )
    smoothness = max(time_span / TICKS_IN_BEAT - SMART_ANCHOR_SMOOTHNESS_OFFSET, 0.0)
    if smoothness <= SMART_ANCHOR_SMOOTHNESS_LIMIT:
        blend_factor = 1.0 / (smoothness * SMART_ANCHOR_BLEND_FALLOFF + 1.0)
    else:
        blend_factor = 0.0
    tangent_slope = blend_factor * slope_right + (1.0 - blend_factor) * slope_left
    return tangent_slope * time_span


@dataclasses.dataclass(frozen=True)
class PitchControlAnchorCurve:
    ticks: list[int]
    values: list[float]

    def value_at_ticks(self, ticks: int) -> float | None:
        index = bisect.bisect_right(self.ticks, ticks) - 1
        if index < 0:
            return None
        if self.ticks[index] == ticks:
            return self.values[index]
        next_index = index + 1
        if next_index >= len(self.ticks):
            return None
        start_tick = self.ticks[index]
        end_tick = self.ticks[next_index]
        if ticks > end_tick:
            return None
        curr_anchor = (start_tick, self.values[index])
        next_anchor = (end_tick, self.values[next_index])
        prev_anchor = (self.ticks[index - 1], self.values[index - 1]) if index > 0 else None
        next_next_anchor = (
            (self.ticks[next_index + 1], self.values[next_index + 1])
            if next_index + 1 < len(self.ticks)
            else None
        )
        m0 = _smart_anchor_tangent(
            prev_anchor, curr_anchor, next_anchor, next_next_anchor, is_start_tangent=True
        )
        m1 = _smart_anchor_tangent(
            prev_anchor, curr_anchor, next_anchor, next_next_anchor, is_start_tangent=False
        )
        t = (ticks - start_tick) / (end_tick - start_tick)
        return _hermite_interpolate(t, curr_anchor[1], next_anchor[1], m0, m1)

    def domain(self) -> portion.Interval:
        if not self.ticks:
            return portion.empty()
        return portion.closed(self.ticks[0], self.ticks[-1])


@dataclasses.dataclass
class PitchControlLayerGenerator:
    _pitch_controls: dataclasses.InitVar[list[PitchControl]]
    interval_dict: PitchControlIntervalMap = dataclasses.field(
        default_factory=PitchControlIntervalMap
    )
    anchor_curve: PitchControlAnchorCurve | None = dataclasses.field(init=False, default=None)

    def __post_init__(self, _pitch_controls: list[PitchControl]) -> None:
        anchors: list[tuple[int, float]] = []
        for pitch_control in _pitch_controls:
            if pitch_control.type_ == "curve" and len(pitch_control.points):
                ticks: list[int] = []
                values: list[float] = []
                for point in pitch_control.points:
                    point_ticks = point.offset + pitch_control.pos
                    point_value = (pitch_control.pitch + point.value) * 100
                    if ticks and ticks[-1] == point_ticks:
                        values[-1] = point_value
                    else:
                        ticks.append(point_ticks)
                        values.append(point_value)
                self.interval_dict.append_curve(PitchControlCurve(ticks=ticks, values=values))
            elif pitch_control.type_ == "point":
                anchors.append((pitch_control.pos, pitch_control.pitch * 100))
        if len(anchors) >= 2:
            anchors.sort()
            anchor_ticks: list[int] = []
            anchor_values: list[float] = []
            for anchor_pos, anchor_value in anchors:
                if anchor_ticks and anchor_ticks[-1] == anchor_pos:
                    anchor_values[-1] = anchor_value
                else:
                    anchor_ticks.append(anchor_pos)
                    anchor_values.append(anchor_value)
            if len(anchor_ticks) >= 2:
                self.anchor_curve = PitchControlAnchorCurve(
                    ticks=anchor_ticks, values=anchor_values
                )

    def value_at_ticks(self, ticks: int) -> float | None:
        value = self.interval_dict.get(ticks)
        if value is not None:
            return value
        if self.anchor_curve is not None:
            return self.anchor_curve.value_at_ticks(ticks)
        return None

    def domain(self) -> portion.Interval:
        result = self.interval_dict.domain()
        if self.anchor_curve is not None:
            result |= self.anchor_curve.domain()
        return result


@dataclasses.dataclass
class SynthVPitchSimulator:
    synchronizer: TimeSynchronizer
    _note_list: dataclasses.InitVar[list[NoteStruct]]
    _pitch_controls: dataclasses.InitVar[list[PitchControl] | None] = None
    base_layer: BaseLayerGenerator = dataclasses.field(init=False)
    gaussian_layer: GaussianLayerGenerator = dataclasses.field(init=False)
    vibrato_layer: VibratoLayerGenerator = dataclasses.field(init=False)
    pitch_control_layer: PitchControlLayerGenerator | None = dataclasses.field(
        init=False, default=None
    )

    def __post_init__(
        self, _note_list: list[NoteStruct], _pitch_controls: list[PitchControl] | None
    ) -> None:
        self.base_layer = BaseLayerGenerator(_note_list)
        self.gaussian_layer = GaussianLayerGenerator(_note_list)
        self.vibrato_layer = VibratoLayerGenerator(_note_list)
        if _pitch_controls:
            self.pitch_control_layer = PitchControlLayerGenerator(_pitch_controls)

    def pitch_at_ticks(self, ticks: int) -> float:
        return self.pitch_at_secs(self.synchronizer.get_actual_secs_from_ticks(ticks), ticks)

    def pitch_at_secs(self, secs: float, ticks: int | None = None) -> float:
        if ticks is None:
            ticks = round(self.synchronizer.get_actual_ticks_from_secs(secs))
        return self._pitch_from_aligned_secs_and_ticks(secs, ticks)

    def _pitch_from_aligned_secs_and_ticks(self, secs: float, ticks: int) -> float:
        if self.pitch_control_layer is not None:
            pitch_control_value = self.pitch_control_layer.value_at_ticks(ticks)
            if pitch_control_value is not None:
                return pitch_control_value
        if not self.base_layer.note_list:
            return 0.0
        return (
            self.base_layer.pitch_at_secs(secs)
            + self.vibrato_layer.pitch_diff_at_secs(secs)
            + self.gaussian_layer.pitch_diff_at_secs(secs)
        )
