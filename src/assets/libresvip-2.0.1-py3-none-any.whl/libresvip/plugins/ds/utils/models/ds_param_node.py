from dataclasses import dataclass


@dataclass
class DsParamNode:
    time: float = 0.0
    value: float = 0.0
