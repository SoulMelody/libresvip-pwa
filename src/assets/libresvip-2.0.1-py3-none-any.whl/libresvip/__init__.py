import os

__version__ = "2.0.1"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
