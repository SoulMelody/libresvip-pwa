from .yaml12 import *

__doc__ = yaml12.__doc__
if hasattr(yaml12, "__all__"):
    __all__ = yaml12.__all__