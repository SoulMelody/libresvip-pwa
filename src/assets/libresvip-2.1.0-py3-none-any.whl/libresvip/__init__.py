import os

__version__ = "2.1.0"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
