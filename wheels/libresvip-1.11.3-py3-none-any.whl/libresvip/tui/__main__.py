from libresvip.tui.app import TUIApp


def main() -> None:
    app = TUIApp()
    app.run()


if __name__ == "__main__":
    main()
