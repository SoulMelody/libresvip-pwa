import os

__version__ = "2.0.6"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
