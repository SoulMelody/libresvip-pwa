from .core import Core


class StreamlitLocalstorageBulk(Core):
    pass
