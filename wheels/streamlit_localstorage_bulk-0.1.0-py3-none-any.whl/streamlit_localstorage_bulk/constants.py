import pkg_resources

VERSION = pkg_resources.get_distribution("streamlit-localstorage-bulk").version
