def test_import_markupsafe():
    from markupsafe import Markup, escape