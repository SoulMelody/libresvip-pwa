def test_numpy():
    import numpy

    ones = numpy.ones(shape=[2,3])
    assert ones.shape == (2,3)