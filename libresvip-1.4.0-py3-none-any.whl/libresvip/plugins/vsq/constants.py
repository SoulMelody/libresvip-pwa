from typing import Final

DEFAULT_PHONEME: Final[str] = "4 a"
