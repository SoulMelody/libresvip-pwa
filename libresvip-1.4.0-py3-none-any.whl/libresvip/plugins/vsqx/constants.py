from typing import Final

DEFAULT_CHINESE_PHONEME: Final[str] = "l a"
DEFAULT_JAPANESE_PHONEME: Final[str] = "4 a"
BPM_RATE: Final[float] = 100.0
