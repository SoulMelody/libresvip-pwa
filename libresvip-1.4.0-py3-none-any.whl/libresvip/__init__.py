import os

__version__ = "1.4.0"
os.environ.setdefault("LOGURU_AUTOINIT", "false")
